# French NLP Toolkit

State of the art toolkit for Natural Language Processing in French.